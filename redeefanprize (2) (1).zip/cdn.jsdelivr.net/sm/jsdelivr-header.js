/**
 * Minified by jsDelivr using Terser v5.39.0.
 * Original file: /npm/canvas-confetti@1.9.3/dist/confetti.browser.js
 *
 * Do NOT use SRI with dynamically generated files! More information: https://www.jsdelivr.com/using-sri-with-dynamic-files
 */
